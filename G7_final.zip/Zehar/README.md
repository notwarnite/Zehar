# Zehar
Dbms project file

download the repository, the framework is self defined but similar to most used in the industry like CodeIgniter.

Try to stick to the directory description available in dummy.txt dont add any <style> tag in any html file, style everything in stylesheets you can make in css.
  
To run:

  go to the directory in your local machine and type in terminal:
    php -S localhost:8000

1st time database setup: 

  in terminal: 
      sudo service mysql-server start
  modify constants.php file and configure as per your machine accounts
  go to browser and type "localhost:8000/database_generator.php";
  and try to debug and setup database yourself, since there might be issues regarding linux dependencies and stuff.

After that everytime:

go to browser and type localhost:8000


