<?php 

// $host = "localhost";
// $port = "5432";
// $dbname = "hotel";
// $user = "postgres";
// $pass = "123";

// $con = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$pass");
// if(!$con) {
//       echo "Error : Unable to open database\n";
//       die ("Could not connect to server\n");
//    } 
// else {
//       echo "Opened database successfully\n";

//    }

include './../constants.php';
$chl = $_POST['chl'];
$chl = '0'.$chl;
$adl = $_POST['adl'];
$adl = '0'.$adl;
// echo $_POST['ari']," ", $_POST['dep']," ", $_POST['chl'], " ", $_POST['adl'], " ";


$sql = "select price from rooms where room_type='".$_POST['type']."'";
$res2 = pg_query($con, $sql);
$res2 = pg_fetch_row($res2);
$res2 = (int) $res2[0];
$checkin = $_POST['ari'];
$checkout = $_POST['dep'];
$checkin = strtotime($checkin);
$checkout = strtotime($checkout);

$diff = $checkout-$checkin;
if($diff < 0) {
   header('location: ./../frontend/login.php');
}
$num_days = round($diff / (60 * 60 * 24));

$amt = $num_days * $res2;

session_start();
$_SESSION['num_days'] = $num_days;
$_SESSION['amt'] = $amt;
$_SESSION['chkin'] = $_POST['ari'];
$_SESSION['chkout'] = $_POST['dep'];
$_SESSION['room_type'] = $_POST['type'];
$_SESSION['children'] = $chl;
$_SESSION['adults'] = $adl;
$_SESSION['num_rooms'] = $_POST['nrooms'];
header('location: ./../frontend/availability.php');
// echo $amt," ", $num_days;




// $sql =<<<EOF
//       INSERT INTO reservation (CHECKIN, CHECKOUT, TYPE, ADULTS, CHILDREN, REQUESTS) VALUES (" . $_POST['checkin']. "," . $_POST['checkout']. " , " . $_POST['type']. ", " . $_POST['adults']. ", " . $_POST['children']. ", " . $_POST['requests']. ");
// EOF;

//    $ret = pg_query($con, $sql);
//    if(!$ret) {
//       echo pg_last_error($con);
//    } else {
//       echo "User details added. \n";
//       // header('Location: login.php');
//    }  

?>