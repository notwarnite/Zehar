<?php 

$host = "localhost";
$port = "5432";
$dbname = "hotel";
$user = "postgres";
$pass = "123";

$con = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$pass");

session_start();
$query = "select rooms_booked from rooms"; 
$rs = pg_query($con, $query);
$sum = 0;
while ( $res = pg_fetch_row($rs)) {
	# code...
	$sum += $res[0];
}

$_SESSION['n_bookings'] = $sum;

$curr = time();
$date = date('Y-m-d');
$time = date('h:i:sa');

$_SESSION['time'] = $time;
$_SESSION['date'] = $date;
$arr = array('SINGLE', 'DOUBLE', 'DELUXE', 'TWIN', 'SUITE', 'SUPREME');
for ($i=0; $i < 6; $i++) { 
	# code...
	$x = 0;
	$sql = "select checkin, checkout from reservation where type ='".$arr[$i]."'";
	$a = pg_query($con, $sql);
	if(!$a) {continue;}
	while($res = pg_fetch_row($a)){
		$b = strtotime($res[0]);
		$c = strtotime($res[1]);
		if( $curr > $c){
			$x++;
		}
	}
	$sql = "update rooms set rooms_booked = rooms_booked + ".$x." where room_type = '".$arr[$i]."'";
	$res = pg_query($con, $sql);
}
for ($i=0; $i < 6; $i++) { 
	# code...
	$x = 0;
	$sql = "select checkin, checkout from reservation where type = '".$arr[$i]."'";
	$a = pg_query($con, $sql);
	if(!$a) {continue;}
	while($res = pg_fetch_row($a)){
		$b = strtotime($res[0]);
		$c = strtotime($res[1]);
		if( $b < $curr and $curr < $c){
			$x+1;
		}
	}
	$sql = "update rooms set rooms_booked = rooms_booked-".$x." where room_type = '".$arr[$i]."'";
	$res = pg_query($con, $sql);
}


header('location: ./../frontend/admin.php')


// header('Location:./../frontend/admin.php');      

?>