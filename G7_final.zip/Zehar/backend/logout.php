<?php
	
	session_start();
	if( isset($_SESSION['loginstat'])) session_destroy();
	header('location: ./../frontend/login.php');
	die();

	

?>