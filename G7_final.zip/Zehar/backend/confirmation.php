<?php

include './../constants.php';
session_start();
$curr = time();
$date = date('Y-m-d');

$sql = "select total_rooms, rooms_booked from rooms where room_type = '".$_SESSION['room_type']."'";
$res = pg_query($con, $sql);
$res = pg_fetch_row($res);

$avail = $res[0] - $res[1];
if($avail <= 0){
	$_SESSION['conf_message'] = "Sorry, the type of rooms you need are not available at that time";
}

$chkin = strtotime($_SESSION['chkin']);
$chkout = strtotime($_SESSION['chkout']);

$sql = "insert into reservation (checkin, checkout, type, adults, children) values ('".$_SESSION['chkin']."', '".$_SESSION['chkout']."', '".$_SESSION['room_type']."', '".$_SESSION['adults']."', '".$_SESSION['children']."')";
$res1 = pg_query($con, $sql);
$sql = "insert into booking (cid, status, roomtype, no_of_rooms) values ('".$_SESSION['cid']."', 'confirmed', '".$_SESSION['room_type']."', '".$_SESSION['num_rooms']."')";
$res2 = pg_query($con, $sql);
$ci = $_SESSION['cid'];
$sql = "select id from booking where cid = $ci order by cid desc limit 1;"; 
$res = pg_query($con, $sql);
$res = pg_fetch_row($res);
$bid = $res[0];
$sql = "insert into pricing(booking_id, nights, total_price, booked_date) values( $bid, '".$_SESSION['num_days']."','" .$_SESSION['amt']. "', '".$date."') ";
$res = pg_query($con, $sql);

header('location: ./../frontend/confirmed.php');



?>