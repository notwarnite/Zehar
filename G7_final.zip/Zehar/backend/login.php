<?php
	include './../constants.php';
	$uname = $_POST['uname'];
	$pass = $_POST['pass'];
	$sql ="select fullname, cid from customer where email='".$uname."' and password='".$pass."';";
	$res = pg_query( $con, $sql);
	if(!$res){
		header('location: ./../frontend/login.php');
		die();
	}
	$res = pg_fetch_row($res);
	session_start();
	$_SESSION['loginstat'] = 1;
	$_SESSION['email'] = $uname;
	$_SESSION['name'] = $res[0];
	$_SESSION['cid'] = $res[1];

	header('location: ./../frontend/index.php');
	die();

	

?>