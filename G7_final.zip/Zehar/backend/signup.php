<?php
	include './../constants.php';
	$email = $_POST['email'];
	$pass = $_POST['epass'];
	$card = $_POST['card'];
	$name = $_POST['uname'];
	$phn = $_POST['phn'];


	$sql = "select cid from customer where email= $email and password = $pass";
	$res = pg_query($con, $sql);
	if($res){
		session_start();
		$_SESSION['exists'] = 1;
		header('location: ./../frontend/login.php');
		die();
	}
	$sql = "insert into customer (FULLNAME, EMAIL, PASSWORD, CARDNUMBER, PHONE) VALUES ('".$name."', '".$email."', '".$pass."', '".$card."', '".$phn."')";
	$res = pg_query($con, $sql);
	if(!$res){
		header('location: ./../frontend/signup.php');
	}
	else{
		header('location: ./../frontend/login.php');
		die();
	}
	

?>