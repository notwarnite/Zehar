<?php include './../constants.php'; ?>

<header>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand mb-0 h1" href="./../index.php">Zehar</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="./../index.php">Home <span class="sr-only"></span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Book</a>
        </li>
        <?php session_start(); echo isset($_SESSION['name'])?'<li class="nav-item">
          <a class="nav-link" href="./../backend/logout.php">Logout</a>
        </li>':'';
        ?>
      </ul>
      <div class="offset-md-7 col-2"> <?php  echo isset($_SESSION['name'])?'Welcome '.$_SESSION['name']: '<a href="./../frontend/login.php">Login</a>'; ?> </div>
    </div>
  </nav>
</header>