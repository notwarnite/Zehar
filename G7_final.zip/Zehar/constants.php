
<?php

//change these constants as per your machine:

$host = "localhost";
$port = "5432";
$dbname = "hotel";
$user = "postgres";
$pass = "123";


$con = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$pass");
 //add anymore constants you want to be universal, throughout all the files:


 $name = "Zehar";
 $base_url = "/";

?>
