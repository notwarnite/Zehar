<?php 
// include 'backend/constants.php';
header('location: frontend/index.php'); 
?>